using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Contracts : System.Web.UI.Page
{
	protected override void OnPreInit(EventArgs e)
	{
		base.OnPreInit(e);
		SearchPanelCtrl.KeywordList = Request.Url.Query;
	}

    protected void Page_Load(object sender, EventArgs e)
    {
    }
}
